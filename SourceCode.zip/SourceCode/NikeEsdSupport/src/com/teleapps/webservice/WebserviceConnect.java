package com.teleapps.webservice;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ConnectException;
import java.net.InetSocketAddress;
import java.net.MalformedURLException;
import java.net.Proxy;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.Base64;
import java.util.HashMap;
import java.util.InputMismatchException;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManagerFactory;

import com.avaya.sce.runtime.tracking.TraceInfo;
import com.avaya.sce.runtimecommon.ITraceInfo;
import com.avaya.sce.runtimecommon.SCESession;
import com.google.json.JsonSanitizer;
import com.teleapps.DataBase.AES;
import com.teleapps.utility.ApplicationConstants;

public class WebserviceConnect {
	


	
	
	String CLASSNAME="WebserviceConnect";
	private HashMap<String, String> property=null;
	
	private String SwnwUserName = "";
	private String SwnwPassword = "";
	private String JksPath = "";
	private String JksPassword = "";
	private int connectTimeout = 0;
	private int readTimeout = 0;
	
	private String ProxyEnable = "";
	private String proxyDomain = "";
	private String proxyPort = "";
	
	
	@SuppressWarnings("unchecked")

	public void setApiCredentials(SCESession mySession) {
			String methodName = "ApiCredentials";
		try {
			AES aes = new AES();
			property = (HashMap<String, String>) mySession.getVariableField("PropertyFields","PropertyValues").getObjectValue();
			SwnwUserName = property.get(ApplicationConstants.Snowusername);
			SwnwPassword = aes.decrypt(property.get(ApplicationConstants.Snowpassword), mySession);
			
			
			
			JksPath = property.get(ApplicationConstants.jksFilePath);
			
			JksPassword = aes.decrypt(property.get(ApplicationConstants.jksPassword), mySession);
			connectTimeout =Integer.parseInt(property.get(ApplicationConstants.ConnectTimeout)) ;
			readTimeout = Integer.parseInt(property.get(ApplicationConstants.ReadTimeout));
			ProxyEnable = property.get(ApplicationConstants.proxyStatus);
			proxyDomain = property.get(ApplicationConstants.proxydomain);
			proxyPort = property.get(ApplicationConstants.proxyPort);
			
			
		}catch(Exception e) {
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| ERROR IN SETTING API CREDENTIALS "+e.getMessage(), mySession);
		}
	}
	
	
	
	public  String getWebService (String request,String method,String jsonbody,SCESession mySession) {
		String methodName = "getWebService";
		
		TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| WEB SERVICE HITTING METHOD ", mySession);
		
		setApiCredentials(mySession);		
		
		String Response = "";
		String sanitizedJson = "";
		HttpsURLConnection connection = null; 
		FileInputStream fileinput = null;
		FileInputStream fileinput_ = null;
		
		
		try
		{
			String Auth = SwnwUserName+":"+SwnwPassword;
			
			Base64.Encoder encode = Base64.getEncoder();
			Auth = encode.encodeToString(Auth.getBytes());
			String Authorization = "Basic "+Auth;
			
			if(jsonbody.isEmpty() || jsonbody.equalsIgnoreCase("NA")) {
				jsonbody = "";
			}
			
			
			


			
			URL url_ = new URL(request);
			fileinput = new FileInputStream(JksPath);
			fileinput_ = new FileInputStream(JksPath);
			KeyStore keyStoreKeys = KeyStore.getInstance("JKS");
			keyStoreKeys.load(fileinput, JksPassword.toCharArray());
			KeyManagerFactory keyMgrFactory = KeyManagerFactory.getInstance("SunX509");
			keyMgrFactory.init(keyStoreKeys,  JksPassword.toCharArray());
			KeyStore trustStore = KeyStore.getInstance("JKS");
			trustStore.load(fileinput_, JksPassword.toCharArray());
			TrustManagerFactory trustManagerFactory = TrustManagerFactory
					.getInstance(TrustManagerFactory.getDefaultAlgorithm());
			trustManagerFactory.init(trustStore);
			SSLContext sslContext = SSLContext.getInstance("TLSv1.2");
			sslContext.init(keyMgrFactory.getKeyManagers(), trustManagerFactory.getTrustManagers(),
					new SecureRandom());
			SSLSocketFactory socketFactory = sslContext.getSocketFactory();
		


		
			HttpsURLConnection.setDefaultSSLSocketFactory(socketFactory);

			if ((ProxyEnable.equalsIgnoreCase("yes")) && (proxyDomain != null && proxyDomain != "NA") && (proxyPort != null && proxyPort != "NA")) {

				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| Enable to Proxy Host ::::: "+ proxyDomain, mySession);
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| Enable to Proxy Port ::::: "+ proxyPort, mySession);
				
				

//				System.setProperty("https.proxyHost", proxyDomain);
//				System.setProperty("https.proxyPort", proxyPort);
//
//				connection = (HttpsURLConnection) url_.openConnection();
				Proxy webProxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(property.get(ApplicationConstants.proxydomain), Integer.parseInt(property.get(ApplicationConstants.proxyPort))));
				
								connection = (HttpsURLConnection) url_.openConnection(webProxy);
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| HTTP PROXY IS ENABLED", mySession);

			} else {

				connection = (HttpsURLConnection) url_.openConnection();

			}

			
			
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| *************Configured Host Verifier ********** : ", mySession);
			
			connectTimeout = connectTimeout*1000;
			readTimeout = readTimeout*1000;
			
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| connectTimeout : "+connectTimeout, mySession);
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| readTimeout : "+readTimeout, mySession);
			/**add request header**/
			connection.setRequestMethod(method);
			connection.setRequestProperty("Authorization", Authorization);
			connection.setRequestProperty("User-Agent", "Mozilla/5.0");
			connection.setRequestProperty("Accept-Language", "en-US,en;q=0.5");
			connection.setRequestProperty("Content-Type", "application/json");
			connection.setConnectTimeout(connectTimeout);
			connection.setReadTimeout(readTimeout);
			connection.setUseCaches(false);
			connection.setDoInput(true);
			connection.setDoOutput(true);
			connection.connect();

			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| API Connection Succes", mySession);

			if(method.equalsIgnoreCase("POST")) {
				//Send request
				DataOutputStream wr = new DataOutputStream ( connection.getOutputStream ());
				wr.writeBytes (jsonbody);
				wr.flush ();
				wr.close ();
			}

			
			if(connection != null) {
				
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| ************* CONNECTION RESPONSE CODE ********** : "+ connection.getResponseCode(), mySession);
				 
				if(connection.getResponseCode()==200) {
				
				 BufferedReader br = new BufferedReader( new InputStreamReader((connection.getInputStream())));
				 

				 String out;
				 while ((out = br.readLine()) != null) 
				 {
					 Response +=out;
				 }
				mySession.getVariableField("API","LinkDown").setValue(false);
				
				}

				else if (connection.getResponseCode()!=200) {
					 BufferedReader br1 = new BufferedReader( new InputStreamReader((connection.getErrorStream())));
					 

					 String out;
					 while ((out = br1.readLine()) != null) 
					 {
						 Response +=out;
					 }
				}
				
				sanitizedJson = JsonSanitizer.sanitize(Response);
				
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| *********** RESPONSE ****************** : " + sanitizedJson, mySession);
				 
//				
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| STATUS CODE "+connection.getResponseCode(), mySession);
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| HTTP_RESPONSE "+sanitizedJson, mySession);
			
				
				mySession.getVariableField("API","ResponseCode").setValue(connection.getResponseCode());
				
				
		}

		} catch (SocketTimeoutException e) {
			mySession.getVariableField("API","LinkDown").setValue(true);
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"|  EXCEPTION WHILE MAKING HTTPS CONNECTION | SOCKETTIMEOUTEXCEPTION ERROR: " + e.getMessage(), mySession);
			return null;
		} catch (ConnectException e) {
			mySession.getVariableField("API","LinkDown").setValue(true);
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| EXCEPTION WHILE MAKING HTTPS CONNECTION | CONNECTEXCEPTION ERROR: " + e.getMessage(), mySession);
			return null;
		} catch (java.net.UnknownHostException e) {
			
			mySession.getVariableField("API","LinkDown").setValue(true);
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| EXCEPTION WHILE MAKING HTTPS CONNECTION | UNKNOWN HOST ERROR: " + e.getMessage(), mySession);
			return null;
		} catch(InputMismatchException e ) {
			mySession.getVariableField("API","LinkDown").setValue(true);
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| EXCEPTION WHILE MAKING HTTPS CONNECTION | UNKNOWN HOST ERROR: " + e.getMessage(), mySession);
			return null;
		} catch (MalformedURLException e) {
			mySession.getVariableField("API","LinkDown").setValue(true);
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| EXCEPTION WHILE MAKING HTTPS CONNECTION  | MalformedURLException: " + e.getMessage(), mySession);
			return null;
		} catch(Exception ex) {
			
			mySession.getVariableField("API","LinkDown").setValue(true);
			
		
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| EXCEPTION WHILE MAKING HTTPS CONNECTION Msg: " + ex.getMessage(), mySession);
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| EXCEPTION WHILE MAKING HTTPS CONNECTION : " + Arrays.toString(ex.getStackTrace()), mySession);
			try {
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| EXCEPTION | RESPONSECODE: " + connection.getResponseCode(), mySession);
			} catch(Exception e) {
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| EXCEPTION WHILE MAKING HTTPS CONNECTION CATCH: " + ex.getMessage(), mySession);
			}
		} finally {
			try {
				fileinput.close();
			} catch (IOException e) {
				
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| EXCEPTION WHILE CLOSING THE INPUTSTEAM OF JKS FILEPATH : " + e, mySession);
			}
			try {
				fileinput_.close();
			} catch (IOException e) {
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| EXCEPTION WHILE CLOSING THE INPUTSTEAM OF JKS FILEPATH : " + e, mySession);
			} 
		}
		return sanitizedJson;
	}
	



}
