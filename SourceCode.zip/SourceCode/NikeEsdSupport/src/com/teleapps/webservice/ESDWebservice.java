package com.teleapps.webservice;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;

import com.avaya.sce.runtime.tracking.TraceInfo;
import com.avaya.sce.runtimecommon.ITraceInfo;
import com.avaya.sce.runtimecommon.SCESession;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.teleapps.DataBase.DBOperations;
import com.teleapps.utility.TimeZoneConversion;





public class ESDWebservice {
	
	String CLASSNAME = "ESDWebservice";
	
	@SuppressWarnings("unchecked")
	public void getANIDetails(String ANI,SCESession mySession ) {
		
		String methodName = "getANIDetails";
		String startdate = "";
		String enddate="";
		String request = "NA";
		String requestBody = "NA";
		String statuscode = "NA" ;
		String response = "NA";
		String VC_FUNCTION_NAME = "VALIDATE_ANI";
		
		String getANIDetailsUrl = "";
		HashMap<String, String> property=null;
		LinkedHashMap<String, String> transaction = null;
		
		try {
			
			transaction = new LinkedHashMap<String,String>();
			mySession.getVariableField("ApplicationVariables","transactionHistory").setValue(transaction);
			
			
			
			property = (HashMap<String, String>) mySession.getVariableField("PropertyFields","PropertyValues").getObjectValue();
			getANIDetailsUrl = property.get("GET_ANI");
			request=getANIDetailsUrl;
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| HTTP_REQUEST_URL "+request, mySession);
			
			requestBody = "{\"Phone\":\""+ANI+"\"}";
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| HTTP_REQUEST "+requestBody, mySession);
			
			startdate=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(new Date());
			
			WebserviceConnect ws = new WebserviceConnect();
			response = ws.getWebService(request, "POST", requestBody, mySession);	
			
			enddate=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(new Date());
			
			
			statuscode = mySession.getVariableField("API","ResponseCode").getStringValue();
			
			transaction = (LinkedHashMap<String, String>) mySession.getVariableField("ApplicationVariables","transactionHistory").getObjectValue();
			
			transaction.put("VC_UCID", "NA");
			transaction.put("VC_CLI_NO", "NA");
			transaction.put("DT_START_DATE", startdate);
			transaction.put("DT_END_DATE", enddate);
			transaction.put("NU_DURATION", "NA");
			transaction.put("VC_FUNCTION_NAME", VC_FUNCTION_NAME);
			transaction.put("VC_HOST_URL", request);
			transaction.put("VC_HOST_REQUEST", requestBody);			
			transaction.put("VC_HOST_RESPONSE", response);
			transaction.put("VC_TRANS_STATUS", "NA");
			transaction.put("VC_USER_INPUT", "");
			

			if(statuscode.equalsIgnoreCase("200")) {
				getResponse(response,VC_FUNCTION_NAME,mySession);
				mySession.getVariableField("API","ANIFound").setValue(true);
			}  else if (statuscode.equalsIgnoreCase("400")) {
				if(response==null || response.isEmpty() || response=="" || response.equalsIgnoreCase("null")) {
					mySession.getVariableField("API","ANIFound").setValue(false);
					mySession.getVariableField("API","Linkdown").setValue(false);
					TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| ***INVALID ANI NUMBER*** | "+statuscode, mySession);
					TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| <-> User details not exist", mySession);
				} else {
					mySession.getVariableField("API","Linkdown").setValue(true);
					TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| ***INVALID SERVICE NOW API URL*** | "+statuscode, mySession);
				}
				
			
			}	else if(statuscode.equalsIgnoreCase("401")) {
				mySession.getVariableField("API","Linkdown").setValue(true);
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| ***INVALID SERVICE NOW API URL*** | "+statuscode, mySession);
			
			}
			
			else if(statuscode.equalsIgnoreCase("401")) {
				mySession.getVariableField("API","Linkdown").setValue(true);
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| ***AUTHENTICATION FAILED FOR SERVICE NOW API*** | "+statuscode, mySession);
			}else {
				mySession.getVariableField("API","Linkdown").setValue(true);
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| ANY OTHER REPONSE CODE OTHER THAN 400 AND 200 | "+statuscode, mySession);

			}
			
			settransactionHistory(mySession);
			
		}catch(Exception e){
			
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| EXCEPTION "+e.getMessage(), mySession);
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| EXCEPTION "+Arrays.toString(e.getStackTrace()), mySession);
			
		}
		
		
	}

	@SuppressWarnings("unchecked")
	public void employeeNumber (String employeeNumber,SCESession mySession ) {

		String methodName = "validate_employee";
		String startdate = "";
		String enddate="";
		String request = "NA";
		String requestBody = "NA";
		String statuscode = "NA" ;
		String response = "NA";
		String VC_FUNCTION_NAME = "VALIDATE_EMPLOYEE_NUMBER";
		
		String getEmployeeNumberUrl = "";
		HashMap<String, String> property=null;
		LinkedHashMap<String, String> transaction = null;
		
		try {
			
			transaction = new LinkedHashMap<String,String>();
			mySession.getVariableField("ApplicationVariables","transactionHistory").setValue(transaction);
			
			startdate=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(new Date());
			
			property = (HashMap<String, String>) mySession.getVariableField("PropertyFields","PropertyValues").getObjectValue();
			getEmployeeNumberUrl = property.get("GET_EMPLOYEE_NUMBER");
			request=getEmployeeNumberUrl;
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| HTTP_REQUEST_URL "+request, mySession);
			
			requestBody = "{\"employeeID\":\""+employeeNumber+"\"}";
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| HTTP_REQUEST "+requestBody, mySession);
			
			
			WebserviceConnect ws = new WebserviceConnect();
			response = ws.getWebService(request, "POST", requestBody, mySession);	
			
			enddate=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(new Date());
			
			
			statuscode = mySession.getVariableField("API","ResponseCode").getStringValue();
			
			transaction = (LinkedHashMap<String, String>) mySession.getVariableField("ApplicationVariables","transactionHistory").getObjectValue();
			
			transaction.put("VC_UCID", "NA");
			transaction.put("VC_CLI_NO", "NA");
			transaction.put("DT_START_DATE", startdate);
			transaction.put("DT_END_DATE", enddate);
			transaction.put("NU_DURATION", "NA");
			transaction.put("VC_FUNCTION_NAME", VC_FUNCTION_NAME);
			transaction.put("VC_HOST_URL", request);
			transaction.put("VC_HOST_REQUEST", requestBody);			
			transaction.put("VC_HOST_RESPONSE", response);
			transaction.put("VC_TRANS_STATUS", "NA");
			transaction.put("VC_USER_INPUT", employeeNumber);
			

			if(statuscode.equalsIgnoreCase("200")) {
				getResponse(response,VC_FUNCTION_NAME,mySession);
				mySession.getVariableField("API","employeeNumberFound").setValue(true);
			}  else if (statuscode.equalsIgnoreCase("400")) {
				if(response==null || response.isEmpty() || response=="" || response.equalsIgnoreCase("null")) {
					mySession.getVariableField("API","employeeNumberFound").setValue(false);
					mySession.getVariableField("API","Linkdown").setValue(false);
					mySession.getVariableField("API","employeeNumberLinkDown").setValue(false);
					TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| ***INVALID EMPLOYEE NUMBER*** | "+statuscode, mySession);
					TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| <-> User details not exist", mySession);
				} else {
					mySession.getVariableField("API","Linkdown").setValue(true);
					mySession.getVariableField("API","employeeNumberLinkDown").setValue(true);
					TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| ***INVALID SERVICE NOW API URL*** | "+statuscode, mySession);
				}
				
			
			}	else if(statuscode.equalsIgnoreCase("401")) {
				mySession.getVariableField("API","Linkdown").setValue(true);
				mySession.getVariableField("API","employeeNumberLinkDown").setValue(true);
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| ***INVALID SERVICE NOW API URL*** | "+statuscode, mySession);
			
			}
			
			else if(statuscode.equalsIgnoreCase("401")) {
				mySession.getVariableField("API","Linkdown").setValue(true);
				mySession.getVariableField("API","employeeNumberLinkDown").setValue(true);
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| ***AUTHENTICATION FAILED FOR SERVICE NOW API*** | "+statuscode, mySession);
			}else {
				mySession.getVariableField("API","employeeNumberLinkDown").setValue(true);
				mySession.getVariableField("API","Linkdown").setValue(true);
				//mySession.getVariableField("API","employeeNumberFound").setValue(false);
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| ANY OTHER REPONSE CODE OTHER THAN 400 AND 200 | "+statuscode, mySession);

			}
			
			settransactionHistory(mySession);

		}catch(Exception e){
			
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| EXCEPTION IN EMPLOYEE NUMBER METHOD: "+e.getMessage(), mySession);
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| EXCEPTION IN EMPLOYEE NUMBER METHOD: "+Arrays.toString(e.getStackTrace()), mySession);
			
		}
		
	
	}
	
	@SuppressWarnings("unchecked")
	public void userName (String userName,SCESession mySession ) {
		
		String methodName = "validate_employee";
		String startdate = "";
		String enddate="";
		String request = "NA";
		String requestBody = "NA";
		String statuscode = "NA" ;
		String response = "NA";
		String VC_FUNCTION_NAME = "VALIDATE_USER_ID";
		
		String getUserNameUrl = "";
		HashMap<String, String> property=null;
		LinkedHashMap<String, String> transaction = null;
		
		try {
			
			transaction = new LinkedHashMap<String,String>();
			mySession.getVariableField("ApplicationVariables","transactionHistory").setValue(transaction);
			
			startdate=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(new Date());
			
			property = (HashMap<String, String>) mySession.getVariableField("PropertyFields","PropertyValues").getObjectValue();
			getUserNameUrl = property.get("GET_USER_NAME");
			request=getUserNameUrl;
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| HTTP_REQUEST_URL "+request, mySession);
			
			requestBody = "{\"UserID\":\""+userName+"\"}";
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| HTTP_REQUEST "+requestBody, mySession);
			
			
			WebserviceConnect ws = new WebserviceConnect();
			response = ws.getWebService(request, "POST", requestBody, mySession);	
			
			enddate=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(new Date());
			
			
			statuscode = mySession.getVariableField("API","ResponseCode").getStringValue();
			
			transaction = (LinkedHashMap<String, String>) mySession.getVariableField("ApplicationVariables","transactionHistory").getObjectValue();
			
			transaction.put("VC_UCID", "NA");
			transaction.put("VC_CLI_NO", "NA");
			transaction.put("DT_START_DATE", startdate);
			transaction.put("DT_END_DATE", enddate);
			transaction.put("NU_DURATION", "NA");
			transaction.put("VC_FUNCTION_NAME", VC_FUNCTION_NAME);
			transaction.put("VC_HOST_URL", request);
			transaction.put("VC_HOST_REQUEST", requestBody);			
			transaction.put("VC_HOST_RESPONSE", response);
			transaction.put("VC_TRANS_STATUS", "NA");
			transaction.put("VC_USER_INPUT", userName);
			

			if(statuscode.equalsIgnoreCase("200")) {
				getResponse(response,VC_FUNCTION_NAME,mySession);
				mySession.getVariableField("API","userNameFound").setValue(true);
			}  else if (statuscode.equalsIgnoreCase("400")) { 
				if(response==null || response.isEmpty() || response=="" || response.equalsIgnoreCase("null")) {
					mySession.getVariableField("API","userNameFound").setValue(false);
					mySession.getVariableField("API","Linkdown").setValue(false);
					mySession.getVariableField("API","userNameLinkDown").setValue(false);
					TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| ***INVALID USER NAME*** | "+statuscode, mySession);
					TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| <-> User details not exist", mySession);
				} else {
					mySession.getVariableField("API","Linkdown").setValue(true);
					mySession.getVariableField("API","userNameLinkDown").setValue(true);
					TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| ***INVALID SERVICE NOW API URL*** | "+statuscode, mySession);
				}
				
			
			}	else if(statuscode.equalsIgnoreCase("401")) {
				mySession.getVariableField("API","Linkdown").setValue(true);
				mySession.getVariableField("API","userNameLinkDown").setValue(true);
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| ***INVALID SERVICE NOW API URL*** | "+statuscode, mySession);
			
			}
			
			else if(statuscode.equalsIgnoreCase("401")) {
				mySession.getVariableField("API","Linkdown").setValue(true);
				mySession.getVariableField("API","userNameLinkDown").setValue(true);
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| ***AUTHENTICATION FAILED FOR SERVICE NOW API*** | "+statuscode, mySession);
			}else {
				mySession.getVariableField("API","Linkdown").setValue(true);
				mySession.getVariableField("API","userNameLinkDown").setValue(true);
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| ANY OTHER REPONSE CODE OTHER THAN 400 AND 200 | "+statuscode, mySession);

			}
			
			settransactionHistory(mySession);

		}catch(Exception e){
			
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| EXCEPTION IN VALIDATE USER NAME METHOD: "+e.getMessage(), mySession);
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| EXCEPTION IN VALIDATE USER NAME METHOD: "+Arrays.toString(e.getStackTrace()), mySession);
			
		}
		
	
		
	}
	
	public void getResponse(String response,String VC_FUNCTION_NAME,SCESession mySession) {
	
		String methodName = "getResponse";
	
		try {

			JsonObject jsonObject = new JsonParser().parse(response).getAsJsonObject();

			
			String emp_no = "NA";
			String user_name = "NA";
			String name = "NA";
			String location = "NA";
			String userSysID = "NA";
			String ELT = "NA";
			String country = "NA";
			String city = "NA";
			String state = "NA";
			String VIP_Identifier = "NA";
			String incident = "NA";
			String request = "NA";
			String VC_VIP_CALLER = "NO";
			
			
			
			JsonObject response_attributes = null;
			
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| <-> Parsing response Json", mySession);
			
			if(jsonObject.has("result")) {
				
			
				response_attributes = jsonObject.getAsJsonObject("result");
				
				if((VC_FUNCTION_NAME.equalsIgnoreCase("VALIDATE_ANI")) || (VC_FUNCTION_NAME.equalsIgnoreCase("VALIDATE_EMPLOYEE_NUMBER") ) ||
						(VC_FUNCTION_NAME.equalsIgnoreCase("VALIDATE_USER_ID"))) {
					if(response_attributes.has("employee_number")){
						emp_no = response_attributes.get("employee_number").getAsString();
					}
					if(response_attributes.has("user_name")) {
						user_name = response_attributes.get("user_name").getAsString();
					} 
					if(response_attributes.has("name")){
						name = response_attributes.get("name").getAsString();
					}
					if(response_attributes.has("location")) {
						location = response_attributes.get("location").getAsString();
					}
					if(response_attributes.has("user_sysID")) {
						userSysID = response_attributes.get("user_sysID").getAsString();
					}
					if(response_attributes.has("ELT")) {
						ELT = response_attributes.get("ELT").getAsString();
					}
					if(response_attributes.has("country")){
						country = response_attributes.get("country").getAsString();
					}
					if(response_attributes.has("vip_identifier")) {
						VIP_Identifier = response_attributes.get("vip_identifier").getAsString();
					}
					if(response_attributes.has("city")){
						city = response_attributes.get("city").getAsString();
					}
					if(response_attributes.has("state")){
						state = response_attributes.get("state").getAsString();
					}
					if(response_attributes.has("incident")){
						incident = response_attributes.get("incident").getAsString();
					}
					if(response_attributes.has("request")){
						request = response_attributes.get("request").getAsString();
					}
					
				} else {
					
					TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| INVALID FUNCTION NAME: "+VC_FUNCTION_NAME , mySession);
					
				}

			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| <-> Employee Number :"+emp_no, mySession);
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| <-> User_Name :"+user_name, mySession);
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| <-> Name :"+name, mySession);
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| <-> Location :"+location, mySession);
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| <-> User sys ID :"+userSysID, mySession);
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| <-> ELT :"+ELT, mySession);
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| <-> Country :"+country, mySession);
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| <-> VIP_Identifier :"+VIP_Identifier, mySession);
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| <-> City :"+city, mySession);
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| <-> State :"+state, mySession);
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| <-> Incident :"+incident, mySession);
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| <-> Request :"+request, mySession);			
			
			mySession.getVariableField("API","employeeNumber").setValue(emp_no);
			mySession.getVariableField("API","UserID").setValue(user_name); 
			//mySession.getVariableField("API","State").setValue(state); 
			mySession.getVariableField("API","Country").setValue(country);
			mySession.getVariableField("API","City").setValue(city);
			mySession.getVariableField("API","State").setValue(state); 
			mySession.getVariableField("API","userSysID").setValue(userSysID); 
			mySession.getVariableField("API","ELT").setValue(ELT); 
			mySession.getVariableField("API","incidentNumber").setValue(incident); 
			mySession.getVariableField("API","requestNumber").setValue(request); 

			if(VC_FUNCTION_NAME.equalsIgnoreCase("VALIDATE_ANI")) {
				mySession.getVariableField("API","ANIFound").setValue(true);
			} else if(VC_FUNCTION_NAME .equalsIgnoreCase("VALIDATE_EMPLOYEE_NUMBER")) {
				mySession.getVariableField("API","employeeNumberFound").setValue(true);
			}else if(VC_FUNCTION_NAME .equalsIgnoreCase("VALIDATE_USER_ID")) {
				mySession.getVariableField("API","userNameFound").setValue(true);
			}
			
			if(VIP_Identifier.equalsIgnoreCase("true")) {
				VC_VIP_CALLER = "YES";
			}

			mySession.getVariableField("Call_History_Fields", "VC_VIP_CALLER").setValue(VC_VIP_CALLER);
				
				
				
			} else {	
				if(VC_FUNCTION_NAME.equalsIgnoreCase("VALIDATE_ANI")) {
				
				mySession.getVariableField("API","ANIFound").setValue(false);
				} else if(VC_FUNCTION_NAME .equalsIgnoreCase("VALIDATE_EMPLOYEE_NUMBER")) {
					mySession.getVariableField("API","employeeNumberFound").setValue(false);
				}else if(VC_FUNCTION_NAME .equalsIgnoreCase("VALIDATE_USER_ID")){
					mySession.getVariableField("API","userNameFound").setValue(true);
				}
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| <-> User details not exist", mySession);
			}
				
		}
		catch(Exception e) {
			
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| EXCEPTION IN getResponse Method "+e.getMessage(), mySession);
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| EXCEPTION IN getResponse Method "+Arrays.toString(e.getStackTrace()), mySession);
		
		}
	}
	
	@SuppressWarnings("unchecked")
	public void settransactionHistory (SCESession mySession) {
		String methodName = "settransactionHistory";
		try {
			String endDate ="NA";
			
			HashMap<String,String> property = new HashMap<String, String>();
			property = (HashMap<String, String>) mySession.getVariableField("PropertyFields","PropertyValues").getObjectValue();
			
			TimeZoneConversion zone = new TimeZoneConversion();

			LinkedHashMap<String, String> transaction = null;
			LinkedHashMap<String, String> callHistory = null;
			callHistory = (LinkedHashMap<String, String>) mySession.getVariableField("ApplicationVariables","callHistory").getObjectValue();
			transaction = (LinkedHashMap<String, String>) mySession.getVariableField("ApplicationVariables","transactionHistory").getObjectValue();
			mySession.getVariableField("ApplicationVariables","transactionHistory").setValue(transaction);;
			
			String ucid = callHistory.get("VC_UCID");
			String cli_no = callHistory.get("VC_CLI_NO");
			String startdate = transaction.get("DT_START_DATE");
			endDate = transaction.get("DT_END_DATE");
			String request_url = transaction.get("VC_HOST_URL");
			String response = transaction.get("VC_HOST_RESPONSE");
			
			
			String TimeZoneFlag = property.get("TIME_ZONE_FLAG");
			
			if(TimeZoneFlag.equalsIgnoreCase("true")) {
				endDate = zone.calculateTimeZone(endDate, mySession);
				startdate = zone.calculateTimeZone(startdate, mySession);
			}
			if(response.equalsIgnoreCase("null")) {
				response ="";
			}
			String VC_FUNCTION_NAME = transaction.get("VC_FUNCTION_NAME");
			String request = transaction.get("VC_HOST_REQUEST");
			String responseCode = mySession.getVariableField("API","ResponseCode").getStringValue();
			String user_input = transaction.get("VC_USER_INPUT");
			
			SimpleDateFormat format = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss"); 
	    	Date date1 = format.parse(startdate);
	    	Date date2 = format.parse(endDate);
	    	long difference = (date2.getTime() - date1.getTime())/1000;
			
			transaction.put("VC_UCID", ucid);
			transaction.put("VC_CLI_NO", cli_no);
			transaction.put("DT_START_DATE", startdate);
			transaction.put("DT_END_DATE", endDate);
			transaction.put("NU_DURATION", Integer.toString((int) difference));
			transaction.put("VC_TRANS_STATUS", responseCode);
			
			
			
			DBOperations db = new DBOperations();
			db.InsertTransactionHistory(ucid, cli_no, startdate,endDate, VC_FUNCTION_NAME, request_url, request, response, responseCode, user_input, mySession);
			
		}catch(Exception e) {
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| EXCEPTION IN GETTING TRANSACTION VALUES "+e.getMessage(), mySession);
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| EXCEPTION IN GETTING TRANSACTION VALUES "+Arrays.toString(e.getStackTrace()), mySession);
		}
	}

}
