package com.teleapps.DataBase;


import java.security.spec.KeySpec;
import java.util.Arrays;
import java.util.Base64;
import java.util.HashMap;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

import com.avaya.sce.runtime.tracking.TraceInfo;
import com.avaya.sce.runtimecommon.ITraceInfo;
import com.avaya.sce.runtimecommon.SCESession;


public class AES {
		String CLASSNAME = "AES";
		
		
		@SuppressWarnings("unchecked")
		public String decrypt(String strToDecrypt,SCESession mySession) {
			
			String methodName = "decrypt";

			String SC_RT_YEK = null;
			String SA_LT = null;
			String SK = null;
			String C_IP_IN = null;
			String A_E_S = null;
			
			HashMap<String, String> property=null;


			try {
				property = (HashMap<String, String>) mySession.getVariableField("PropertyFields","PropertyValues").getObjectValue();

				int T_LEN = 128;

				SC_RT_YEK = property.get("KEYSPEC");
				SA_LT = property.get("SALT");
				SK = property.get("SECRET_KEY");
				C_IP_IN = property.get("CIPHER");
				A_E_S = property.get("AES");
				


				AES util = new AES();

				byte[] iv = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
				GCMParameterSpec ivspec = new GCMParameterSpec(T_LEN, iv);
				SecretKeyFactory factory = SecretKeyFactory.getInstance(util.dec(SK, mySession));
				KeySpec spec = new PBEKeySpec(util.dec(SC_RT_YEK, mySession).toCharArray(), util.dec(SA_LT, mySession).getBytes(), 65536, 256);
				SecretKey tmp = factory.generateSecret(spec);
				SecretKeySpec secretKey = new SecretKeySpec(tmp.getEncoded(), util.dec(A_E_S, mySession));

				Cipher cipher = Cipher.getInstance(util.dec(C_IP_IN, mySession));
				cipher.init(Cipher.DECRYPT_MODE, secretKey, ivspec);
				return new String(cipher.doFinal(Base64.getDecoder().decode(strToDecrypt)));

			} catch (Exception e) {
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| ERROR WHILE SEND DECRYPTING: "+e.getMessage(), mySession);
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| ERROR WHILE SEND DECRYPTING: "+Arrays.toString(e.getStackTrace()), mySession);
				return "NA";

			}

		}
	
	
	public String dec(String value, SCESession mySession) {

		
		String methodName = "decrypt";
		
		try {

			byte[] decBytes = Base64.getDecoder().decode(value);
			String deString = new String(decBytes);
			return deString;

		} catch(Exception e) {
			
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR,CLASSNAME+"|"+methodName+"| ERROR WHILE DECRYPTING: "+e.getMessage(), mySession);
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR,CLASSNAME+"|"+methodName+"| ERROR WHILE DECRYPTING: "+Arrays.toString(e.getStackTrace()), mySession);

		}

		return null;
	}
	
//	public static String encrypt(String strToEncrypt) {
//	
//	String methodName = "encrypt";
//
//	int T_LEN = 128;
//	
//	try {
//		String SECRET_KEY = "P0lL@tHaV0n$18@9AprL";
//		String SALT = "Cts@12345";
//				//"Cts@12345";
//		byte[] iv = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
//
//		GCMParameterSpec ivspec = new GCMParameterSpec(T_LEN, iv);
//
//		SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
//		KeySpec spec = new PBEKeySpec(SECRET_KEY.toCharArray(), SALT.getBytes(), 65536, 256);
//		SecretKey tmp = factory.generateSecret(spec);
//		SecretKeySpec secretKey = new SecretKeySpec(tmp.getEncoded(), "AES");
//
//		Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
//		cipher.init(Cipher.ENCRYPT_MODE, secretKey, ivspec);
//		return Base64.getEncoder()
//				.encodeToString(cipher.doFinal(strToEncrypt.getBytes(StandardCharsets.UTF_8)));
//	} catch (Exception e) {
//		System.out.println("ERROR WHILE ENCRYPTING: " + Arrays.toString(e.getStackTrace()));
//	}
//	return null;
//	
//}
	

	
	
	
	
}
