package com.teleapps.DataBase;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;


import com.avaya.sce.runtime.tracking.TraceInfo;
import com.avaya.sce.runtimecommon.ITraceInfo;
import com.avaya.sce.runtimecommon.SCESession;
import com.google.gson.JsonObject;
import com.teleapps.utility.ApplicationConstants;


public class FlatFileWriter {
	
	/*@SuppressWarnings("unchecked")
	public void createFlatFile(String tableName,LinkedHashMap<String, String> linkedHashMap,String fileNameWithExtension,SCESession mySession) {
		
		String CLASSNAME="FlatFile";
		String methodName = "createFlatFile";
		
		TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| START CREATING FLAT FILE ", mySession);
		
		HashMap<String,String> property = new HashMap<String, String>();
		property = (HashMap<String, String>) mySession.getVariableField("PropertyFields","PropertyValues").getObjectValue();
		
		String fileLocation = property.get(ApplicationConstants.flatFilePath);

		

		String openBracket = "(";
		String closedBracket = ")";
		String comma = ",";
		String singleQuote = "";
		String value = "";
		String queryStart = "";

		File file = null;

		FileWriter fw = null;
		BufferedWriter bw = null;

		try {

		int i=0;
		for (Entry<String, String> entry : linkedHashMap.entrySet()) {
		i++;

		singleQuote = "'";
		if(entry.getKey().startsWith("NU")) singleQuote = "";
		if(i==linkedHashMap.size()) comma=closedBracket;

		value =entry.getValue();
		value=singleQuote+value+singleQuote;
		openBracket+=value+comma;
		}

		String currentDate=new SimpleDateFormat("ddMMyyyy").format(new Date());
		createMissingDirs(fileLocation,mySession);
		fileLocation = fileLocation+fileNameWithExtension+currentDate+".txt";

		TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| FLAT FILE PATH:  "+fileLocation, mySession);
		file = new File(fileLocation);

		if(file.exists()) {
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"|FILE IS PRESENT", mySession);
			} else 
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"|FILE NOT EXISTS", mySession);

		if(file.length()==0) queryStart = "INSERT INTO "+tableName+" VALUES";

		fw = new FileWriter(file,true);
		bw = new BufferedWriter(fw);

		if(file.length()!=0){
		bw.write(",");
		bw.newLine();
		}

		bw.write(queryStart+openBracket);
		TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| FLAT FILE WRITTEN SUCCESSFULLY", mySession);
		
		bw.flush();
			
		} catch(Exception e) {
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| EXCEPTION IN FLAT FILE CREATION : "+e.getMessage(), mySession);
		} finally {
		try {
		if(fw!=null) fw.close();
		if(bw!=null) bw.close();

		} catch (IOException e) {
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| EXCEPTION IN FLAT FILE CREATION : "+e.getMessage(), mySession);
		}
		}
		}
	public static void createMissingDirs(String location,SCESession mySession) {
		String CLASSNAME="FlatFile";
		String methodName = "createFlatFile";
		try {
		File theDir = new File(location);
		if (!theDir.exists()){
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"|MISSING FOLDER ARE CREATED: "+location, mySession);
		theDir.mkdirs();
		} else {
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| ALL FOLDERS ARE PRESENT  "+location, mySession);
		}
		
		} catch(Exception e) {
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| EXCEPTION IN CREATING FLAT FILE LOCATION : "+e.getMessage(), mySession);
		}
		}*/

	
	@SuppressWarnings("unchecked")
	public boolean createFlatFile(JsonObject insertHistory,String fileName,SCESession mySession) {

		String CLASSNAME="FlatFile";
		String methodName = "createFlatFile";
		//String flow = "Externl_JAR";
		TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| START CREATING FLAT FILE ", mySession);
		//Root root = null; 
		
		HashMap <String, String> propertyFile = new HashMap<String,String>();
		try {
			//root = (Root) mySession.getVariableField("applicationProperties").getObjectValue();
			propertyFile = (HashMap<String, String>) mySession.getVariableField("PropertyFields","PropertyValues").getObjectValue();
		}catch(Exception e) {
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR,CLASSNAME+"|"+methodName+"| ERROR IN GETTING VALUES FROM CONFIG FILES  "+e.getMessage()+"/n"+Arrays.toString(e.getStackTrace()), mySession);	
		}
		String fileLocation = propertyFile.get(ApplicationConstants.flatFilePath);
		
		File file = null;

		FileWriter fw = null;
		BufferedWriter bw = null;

		try {

			String currentDate=new SimpleDateFormat("yyyy-MM-dd").format(new Date());

			if(createMissingDirs(fileLocation,mySession)) {
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO,CLASSNAME+"|"+methodName+"| CREATED OR FOUND THE FLATFILE LOCATION"+fileLocation, mySession);

			}else {
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR,CLASSNAME+"|"+methodName+"| EXCEPTION OCCUERD IN createMissingDirs METHOD", mySession);

			}
			fileLocation = fileLocation+currentDate+"_"+fileName+".json";

			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| FLAT FILE PATH:  "+fileLocation, mySession);
			file = new File(fileLocation);

			if(file.exists()) {
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"|FILE IS PRESENT", mySession);
			} else 
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"|FILE NOT EXISTS", mySession);

			fw = new FileWriter(file,true);
			bw = new BufferedWriter(fw);

			if(file.length()!=0){
				bw.newLine();
			}

			bw.write(insertHistory.toString());
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| FLAT FILE WRITTEN SUCCESSFULLY", mySession);

			bw.flush();
			return true;
		} catch(Exception e) {
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| EXCEPTION IN FLAT FILE CREATION : "+e.getMessage(), mySession);
		} finally {
			try {
				if(fw!=null) fw.close();
				if(bw!=null) bw.close();
			} catch (IOException e) {
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| EXCEPTION IN FLAT FILE CREATION : "+e.getMessage(), mySession);
				
			}
		}
		return false;
	}
	public boolean createMissingDirs(String location,SCESession mySession) {
		String CLASSNAME="FlatFile";
		String methodName = "createFlatFile";
		try {
			File theDir = new File(location);
			if (!theDir.exists()){
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"|MISSING FOLDER ARE CREATED: "+location, mySession);
				theDir.mkdirs();
			} else {
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| ALL FOLDERS ARE PRESENT  "+location, mySession);
			}
			return true;
		} catch(Exception e) {
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| EXCEPTION IN CREATING FLAT FILE LOCATION : "+e.getMessage(), mySession);
		}
		return false;
	}

	
}
