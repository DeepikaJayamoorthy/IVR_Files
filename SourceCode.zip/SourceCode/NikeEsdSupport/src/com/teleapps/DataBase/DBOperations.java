package com.teleapps.DataBase;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;

import org.apache.commons.dbcp2.BasicDataSource;

import com.avaya.sce.runtime.tracking.TraceInfo;
import com.avaya.sce.runtimecommon.ITraceInfo;
import com.avaya.sce.runtimecommon.SCESession;
import com.google.gson.Gson;
import com.google.gson.JsonParser;
import com.teleapps.utility.ApplicationConstants;
import com.teleapps.utility.MenuHistoryDT;


public class DBOperations {


	//Connection con = null;
	//public String db_url;
	String CLASSNAME = "DBOperations";

	//public static BasicDataSource dataSource;
	//public static BasicDataSource failOverDataSource;
	//String Primary_DB_IP = "";
	//String FailOver_DB_IP = ""; 
	//String DB_User = "";
	//String DB_Password = "";
	//String DB_Name = "";
	//int MinIdle = 0;
	//int MaxIdle = 0;
	//int DB_TimeOut = 0;
	//int defaultQueryTimeout = 0;
	//int MaxOpenPreparedStatements = 0;

	
	private static BasicDataSource dataSource;

	private BasicDataSource getDataSource(String DB_IP, String DB_User, String DB_Password, String DB_Name, int MinIdle, int MaxIdle, int DB_TimeOut,int MaxOpenPreparedStatements, int defaultQueryTimeout, SCESession mySession){

		String methodName = "getDataSource";
		BasicDataSource ds = null;

		try{

			ds = new BasicDataSource();
			ds.setDriverClassName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			ds.setUrl("jdbc:sqlserver://"+DB_IP+";user="+DB_User+";password="+DB_Password+";databasename="+DB_Name+";loginTimeout="+DB_TimeOut);
			ds.setMinIdle(MinIdle);
			ds.setMaxIdle(MaxIdle);
			ds.setMaxOpenPreparedStatements(MaxOpenPreparedStatements);
			ds.setDefaultQueryTimeout(defaultQueryTimeout);

			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, " | "+methodName+" | New Url Framed for Data Base Connection", mySession);
			mySession.getVariableField("ApplicationVariables", "DBException").setValue(ApplicationConstants.F);

		} catch(Exception e){

			mySession.getVariableField("ApplicationVariables", "DBException").setValue(ApplicationConstants.T);
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, " | "+methodName+" | Exception While framing Data Base URL | \n"+Arrays.toString(e.getStackTrace()), mySession);

		}

		return ds;

	}

	@SuppressWarnings("unchecked")
	public void createURL(SCESession mySession) {

		String methodName = "CreateURL";

		HashMap<String,String> property = new HashMap<String, String>();
		property = (HashMap<String, String>) mySession.getVariableField("PropertyFields","PropertyValues").getObjectValue();

		String Primary_DB_IP =property.get(ApplicationConstants.DB_Primary_IP).toString();
		String DB_User = property.get(ApplicationConstants.DB_Username).toString();
		String encryptedValue = property.get(ApplicationConstants.DB_Password).toString();
		String DB_Password = new AES().decrypt(encryptedValue, mySession);
		String DB_Name = property.get(ApplicationConstants.DB_Schema).toString();
		int MinIdle = Integer.parseInt(property.get(ApplicationConstants.DB_MinIdle));
		int MaxIdle = Integer.parseInt(property.get(ApplicationConstants.DB_MaxIdle));
		int DB_TimeOut  = Integer.parseInt(property.get(ApplicationConstants.DB_Timeout));
		int MaxOpenPreparedStatements = Integer.parseInt(property.get(ApplicationConstants.DB_Open_Prepared_Statement));
		int defaultQueryTimeout = Integer.parseInt(property.get(ApplicationConstants.DB_DefaultQueryTimeout).toString());

		try {

			dataSource = new DBOperations().getDataSource(Primary_DB_IP, DB_User, DB_Password, DB_Name, MinIdle, MaxIdle, DB_TimeOut,MaxOpenPreparedStatements, defaultQueryTimeout, mySession);
			mySession.getVariableField("ApplicationVariables", "DBException").setValue(ApplicationConstants.F);

		} catch (Exception e){

			mySession.getVariableField("ApplicationVariables", "DBException").setValue(ApplicationConstants.T);
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, " | "+methodName+" | Exception While Creating Data Base URL | \n"+Arrays.toString(e.getStackTrace()), mySession);

		}

	}

	private Connection openConnection(SCESession mySession) {

		Connection con = null;
		String methodName = "openConnection";
		try {

			con = dataSource.getConnection();

			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, " | "+methodName+" | Sql Connection Created", mySession);
			mySession.getVariableField("ApplicationVariables","DBException").setValue(ApplicationConstants.F);
			return con;

		} catch (SQLException e) {

			mySession.getVariableField("ApplicationVariables","DBException").setValue(ApplicationConstants.T);
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, " | "+methodName+" | Sql Exception Received while Creating Data Base Connection | \n"+Arrays.toString(e.getStackTrace()), mySession);

		} catch (Exception e) {

			mySession.getVariableField("ApplicationVariables","DBException").setValue(ApplicationConstants.T);
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, " | "+methodName+" | General Exception while Creating Sql Connection | \n"+Arrays.toString(e.getStackTrace()), mySession);

		}
		return con;

	}

	private boolean closeConnection(Connection con, SCESession mySession) {

		String methodName = "closeConnection";
		try {
			
			if ( con != null && con.isClosed() != true ) {
				con.close();
			}
			
		} catch(Exception e) {

			mySession.getVariableField("ApplicationVariables","DBException").setValue(ApplicationConstants.T);
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, " | "+methodName+" | General Exception while Creating Sql Connection | \n"+Arrays.toString(e.getStackTrace()), mySession);

		}

		return false;
	}
	

	
	
	
	
	
	
	/*private BasicDataSource getDataSource(String DB_IP, String DB_User, String DB_Password, String DB_Name, int MinIdle, int MaxIdle, int DB_TimeOut,int MaxOpenPreparedStatements, SCESession mySession){
		String methodName = "getDataSource";
		BasicDataSource ds = new BasicDataSource();

		try{
			ds.setDriverClassName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

			ds.setUrl("jdbc:sqlserver://"+DB_IP+";user="+DB_User+";password="+DB_Password+";databasename="+DB_Name+";loginTimeout="+DB_TimeOut);

			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| DB URL: "+"jdbc:sqlserver://"+DB_IP+";user="+DB_User+";password="+DB_Password+";databasename="+DB_Name+";loginTimeout="+DB_TimeOut, mySession);

			ds.setMinIdle(MinIdle);
			ds.setMaxIdle(MaxIdle);
			ds.setMaxOpenPreparedStatements(MaxOpenPreparedStatements);
			ds.setDefaultQueryTimeout(defaultQueryTimeout);

			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| DB URL_CREATED ", mySession);

		} catch(Exception e){

			mySession.getVariableField("ApplicationVariables", "DBException").setValue(true);
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| EXCEPTION_WHILE_CREATING_URL : "+e.getMessage(), mySession);
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| EXCEPTION_WHILE_CREATING_URL : "+Arrays.toString(e.getStackTrace()), mySession);
		}
		return ds;
	}

	@SuppressWarnings("unchecked")
	public void CreateURL(SCESession mySession) {

		String methodName = "CreateURL";
		AES aes = new AES();

		HashMap<String,String> property = new HashMap<String, String>();
		property = (HashMap<String, String>) mySession.getVariableField("PropertyFields","PropertyValues").getObjectValue();

		TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| CREATING DB URL", mySession);

		Primary_DB_IP =property.get(ApplicationConstants.DB_Primary_IP).toString();
		DB_User = property.get(ApplicationConstants.DB_Username).toString();
		String encryptedValue = property.get(ApplicationConstants.DB_Password).toString();
		DB_Password = aes.decrypt(encryptedValue, mySession);
		DB_Name = property.get(ApplicationConstants.DB_Schema).toString();
		MinIdle = Integer.parseInt(property.get(ApplicationConstants.DB_MinIdle));
		MaxIdle = Integer.parseInt(property.get(ApplicationConstants.DB_MaxIdle));
		DB_TimeOut  = Integer.parseInt(property.get(ApplicationConstants.DB_Timeout));
		MaxOpenPreparedStatements = Integer.parseInt(property.get(ApplicationConstants.DB_Open_Prepared_Statement));
		defaultQueryTimeout = Integer.parseInt(property.get(ApplicationConstants.DB_DefaultQueryTimeout).toString());



		try {
			//boolean isPropModified = mySession.getVariableField("PropertyFields","IsPropModified").getBooleanValue();

			
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| PROP FILE MODIFIED, GETTING NEW DATA SOURCE  ", mySession);
				dataSource = new DBOperations().getDataSource(Primary_DB_IP, DB_User, DB_Password, DB_Name, MinIdle, MaxIdle, DB_TimeOut,MaxOpenPreparedStatements, mySession);
			

			mySession.getVariableField("ApplicationVariables", "DBException").setValue(false);

		} catch (Exception e){

			mySession.getVariableField("ApplicationVariables", "DBException").setValue(true);
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| EXCEPTION_WHILE_CREATING_URL : "+e.getMessage(), mySession);
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| EXCEPTION_WHILE_CREATING_URL : "+Arrays.toString(e.getStackTrace()), mySession);
		}
	}

	boolean db_open (SCESession mySession){

		String methodName = "db_open";
		try 
		{
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| CREATING SQL CONNECTION", mySession);

			con = dataSource.getConnection();

			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| SQL CONNECTION CREATED", mySession);
			mySession.getVariableField("ApplicationVariables","DBException").setValue(false);
			return true;

		} catch (SQLException e) {

			mySession.getVariableField("ApplicationVariables","DBException").setValue(true);

			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| SQL EXCEPTION : "+e.getMessage(), mySession);

		}

		catch (Exception e) 
		{
			mySession.getVariableField("ApplicationVariables","DBException").setValue(ApplicationConstants.T);
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| EXCEPTION : "+e.getMessage(), mySession);
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| EXCEPTION : "+Arrays.toString(e.getStackTrace()), mySession);
		}
		return false;
	}

	boolean check_connection (SCESession mySession)
	{
		String methodName = "check_connection";
		try 
		{
			if ( con == null || con.isClosed() == true )
			{
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| SQL CONNECTION IS NULL OR CLOSED", mySession);

				return db_open(mySession);
			} else {

				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| SQL CONNECTION IS ALREADY OPENED", mySession);
			}
		} catch (SQLException e) 
		{
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| SQL CONNECTION EXCEPTION : "+e.getMessage(), mySession);
			mySession.getVariableField("ApplicationVariables","DBException").setValue(ApplicationConstants.T);
		} 
		catch (Exception e) 
		{
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| SQL CONNECTION EXCEPTION : "+e.getMessage(), mySession);
			mySession.getVariableField("ApplicationVariables","DBException").setValue(ApplicationConstants.T);
		}

		return true;
	}*/



	@SuppressWarnings("unchecked")
	public boolean InsertCallHistory(String VC_UCID,String VC_CLI_NO,String VC_DNIS,String VC_LANGUAGE,String DT_START_DATE,String DT_END_DATE,String VC_VIP_CALLER,
			String VC_MENU_DESCRIPTION,String VC_END_MENU_DESC,String VC_EXIT_LOCATION,String VC_CALL_END_REASON,String VC_TRANSFER_VDN,
			String VC_SESSION_MPP_ID,String VC_APP_SRVR_IP,String VC_UUI,SCESession mySession)
	{

		String methodName = "InsertCallHistory";
		CallableStatement stmt = null;
		boolean returnFlag = false;
		String exception = mySession.getVariableField("ApplicationVariables","DBException").getStringValue();
		HashMap<String,String> property = new HashMap<String, String>();
		property = (HashMap<String, String>) mySession.getVariableField("PropertyFields","PropertyValues").getObjectValue();
		int defaultQueryTimeout = Integer.parseInt(property.get(ApplicationConstants.DB_DefaultQueryTimeout).toString());
		Connection con = openConnection(mySession);
		try 
		{
			if(exception.equalsIgnoreCase(ApplicationConstants.F)) {


				if(con!=null) {

					if(exception.equalsIgnoreCase(ApplicationConstants.T)){

						TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| CONNECTION EXCEPTION WHILE CONNECTING DB",  mySession);


						LinkedHashMap<String,String> callHistory = new LinkedHashMap<String, String>();
						callHistory = (LinkedHashMap<String, String>) mySession.getVariableField("ApplicationVariables","callHistory").getObjectValue();
						FlatFileWriter ffw = new FlatFileWriter();
						String jsonString = new Gson().toJson(callHistory);
						ffw.createFlatFile(new JsonParser().parse(jsonString).getAsJsonObject(), "CallHistory", mySession);
						


					}
					else
					{  
						if(mySession.isAppTraceEnabled())
						{
							TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| SP_INSERT_IVR_CALL_HISTORY : ",  mySession);
							TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| VC_UCID : " 					+ VC_UCID, mySession);
							TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| VC_CLI_NO : " 				+ VC_CLI_NO, mySession);
							TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| VC_DNIS : "			        + VC_DNIS, mySession);
							TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| VC_LANGUAGE : "				+ VC_LANGUAGE, mySession);
							TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| DT_START_DATE : "		 	    + DT_START_DATE, mySession);
							TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| DT_END_DATE :"				+ DT_END_DATE, mySession);
							TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| VC_VIP_CALLER :"			+ VC_VIP_CALLER, mySession);
							TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| VC_MENU_DESCRIPTION: " 			+ VC_MENU_DESCRIPTION, mySession);
							TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| VC_END_MENU_DESC : " 			+ VC_END_MENU_DESC, mySession);
							TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| VC_EXIT_LOCATION : " 		+ VC_EXIT_LOCATION, mySession);
							TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| VC_CALL_END_REASON : " 		+ VC_CALL_END_REASON, mySession);					
							TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| VC_TRANSFER_VDN : " 		        + VC_TRANSFER_VDN, mySession);					
							TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| VC_SESSION_MPP_ID : " 			+ VC_SESSION_MPP_ID, mySession);
							TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| VC_APP_SRVR_IP : " 			+ VC_APP_SRVR_IP, mySession);
							TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| VC_UUI : " 			+ VC_UUI, mySession);

						}
						
						stmt = con.prepareCall("{call dbo.SP_INSERT_IVR_CALL_HISTORY(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) }");
						stmt.setString(1, VC_UCID);
						stmt.setString(2, VC_CLI_NO); 
						stmt.setString(3, VC_DNIS);
						stmt.setString(4, VC_LANGUAGE);
						stmt.setString(5, DT_START_DATE);
						stmt.setString(6, DT_END_DATE);	
						stmt.setString(7, VC_VIP_CALLER);
						stmt.setString(8, VC_MENU_DESCRIPTION); 
						stmt.setString(9, VC_END_MENU_DESC);
						stmt.setString(10, VC_EXIT_LOCATION);
						stmt.setString(11, VC_CALL_END_REASON); 
						stmt.setString(12, VC_TRANSFER_VDN); 
						stmt.setString(13, VC_SESSION_MPP_ID);  
						stmt.setString(14, VC_APP_SRVR_IP);
						stmt.setString(15, VC_UUI);
						stmt.setQueryTimeout(defaultQueryTimeout);
						stmt.execute();


						mySession.getVariableField("ApplicationVariables","DBException").setValue(ApplicationConstants.F);



						mySession.getVariableField("ApplicationVariables","SPException").setValue(ApplicationConstants.F);
						mySession.getVariableField("ApplicationVariables","IsCallHistoryInsertedFlag").setValue(ApplicationConstants.T);
						TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| CALL HISTORY INSERTED SUCCESSFULLY  ",mySession);
						returnFlag = true;				
					}
				} else {

					TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| DB EXCEPTION OCCURRED.HENCE CREATING FLAT FILE",mySession);
					LinkedHashMap<String,String> callHistory = new LinkedHashMap<String, String>();
					callHistory = (LinkedHashMap<String, String>) mySession.getVariableField("ApplicationVariables","callHistory").getObjectValue();
					FlatFileWriter ffw = new FlatFileWriter();
					//ffw.createFlatFile("IVR_CALL_HISTORY", callHistory, "CallHistory", mySession);
					//JSONObject flatFileCallHistory = new JSONObject(callHistory);
					String jsonString = new Gson().toJson(callHistory);
					ffw.createFlatFile(new JsonParser().parse(jsonString).getAsJsonObject(), "CallHistory", mySession);

					mySession.getVariableField("ApplicationVariables","IsCallHistoryInsertedFlag").setValue(ApplicationConstants.T);

				}
			} else {
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| DB EXCEPTION OCCURRED.HENCE CREATING FLAT FILE",mySession);
				LinkedHashMap<String,String> callHistory = new LinkedHashMap<String, String>();
				callHistory = (LinkedHashMap<String, String>) mySession.getVariableField("ApplicationVariables","callHistory").getObjectValue();
				FlatFileWriter ffw = new FlatFileWriter();
				String jsonString = new Gson().toJson(callHistory);
				ffw.createFlatFile(new JsonParser().parse(jsonString).getAsJsonObject(), "CallHistory", mySession);
				//ffw.createFlatFile("IVR_CALL_HISTORY", callHistory, "CallHistory", mySession);
				mySession.getVariableField("ApplicationVariables","IsCallHistoryInsertedFlag").setValue(ApplicationConstants.T);
			}

		}
		catch (Exception e) 
		{
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| DB EXCEPTION OCCURRED.HENCE CREATING FLAT FILE",mySession);
			LinkedHashMap<String,String> callHistory = new LinkedHashMap<String, String>();

			callHistory = (LinkedHashMap<String, String>) mySession.getVariableField("ApplicationVariables","callHistory").getObjectValue();
			FlatFileWriter ffw = new FlatFileWriter();
			String jsonString = new Gson().toJson(callHistory);
			ffw.createFlatFile(new JsonParser().parse(jsonString).getAsJsonObject(), "CallHistory", mySession);
			//ffw.createFlatFile("IVR_CALL_HISTORY", callHistory, "CallHistory", mySession);
			mySession.getVariableField("ApplicationVariables","IsCallHistoryInsertedFlag").setValue(ApplicationConstants.T);

			mySession.getVariableField("ApplicationVariables","SPException").setValue(ApplicationConstants.T);
			mySession.getVariableField("ApplicationVariables","DBException").setValue(ApplicationConstants.T);


			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| SP_INSERT_IVR_CALL_HISTORY | DB Connection Error : "+e.getMessage(),mySession);
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| SP_INSERT_IVR_CALL_HISTORY | DB Connection Error : "+Arrays.toString(e.getStackTrace()),mySession);
		}
		finally
		{
			try {

				String exception_1 = mySession.getVariableField("ApplicationVariables","SPException").getStringValue();
				if(exception_1.equalsIgnoreCase(ApplicationConstants.T))
				{
					TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| CONNECTION EXCEPTION WHILE EXECUTE CALL HISTORY SP : ",  mySession);
					TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| DB EXCEPTION OCCURRED.HENCE CREATING FLAT FILE",mySession);

					LinkedHashMap<String,String> callHistory = new LinkedHashMap<String, String>();
					callHistory = (LinkedHashMap<String, String>) mySession.getVariableField("ApplicationVariables","callHistory").getObjectValue();
					FlatFileWriter ffw = new FlatFileWriter();
					//ffw.createFlatFile("IVR_CALL_HISTORY", callHistory, "CallHistory", mySession);
					String jsonString = new Gson().toJson(callHistory);
					ffw.createFlatFile(new JsonParser().parse(jsonString).getAsJsonObject(), "CallHistory", mySession);
					mySession.getVariableField("ApplicationVariables","IsCallHistoryInsertedFlag").setValue(ApplicationConstants.T);

					mySession.getVariableField("ApplicationVariables","SPException").setValue(ApplicationConstants.F);
				}
				try {

					if(stmt!=null) {
						stmt.close();
					}
					if(con!=null) {
						closeConnection(con, mySession);
						TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| SQL CONNECTION CLOSED |",mySession);
					} else {
						TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| SQL CONNECTION IS NULL |",mySession);
					}


				}catch (Exception es) {
					TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| SQL CLOSE CONNECTION EXCEPTION|"+es.getMessage(),mySession);
				}
			} catch (Exception e) {
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| SP_INSERT_IVR_CALL_HISTORY | DB Close Connection Error : "+e.getMessage(),mySession);
			}
		}
		return returnFlag;	
	}

	@SuppressWarnings("unchecked")
	public boolean InsertTransactionHistory(String VC_UCID,String VC_CLI_NO,String DT_START_DATE,String DT_END_DATE,String VC_FUNCTION_NAME,
			String VC_HOST_URL,String VC_HOST_REQUEST, String VC_HOST_RESPONSE,String VC_TRANS_STATUS,String VC_USER_INPUT,SCESession mySession)
	{
		String methodName = "InsertTransactionHistory";
		CallableStatement stmt = null;
		boolean returnFlag = false;
		String exception = mySession.getVariableField("ApplicationVariables","DBException").getStringValue();
		HashMap<String,String> property = new HashMap<String, String>();
		property = (HashMap<String, String>) mySession.getVariableField("PropertyFields","PropertyValues").getObjectValue();
		int defaultQueryTimeout = Integer.parseInt(property.get(ApplicationConstants.DB_DefaultQueryTimeout).toString());
		Connection con = openConnection(mySession);

		try
		{
			if(exception.equalsIgnoreCase(ApplicationConstants.F)) {


				if(con!=null) {


					if(exception.equalsIgnoreCase(ApplicationConstants.T))
					{
						TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| CONNECTION EXCEPTION WHILE CONNECTING DB: ",  mySession);
						TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| DB EXCEPTION OCCURRED.HENCE CREATING FLAT FILE",mySession);

						LinkedHashMap<String,String> transaction = new LinkedHashMap<String, String>();
						transaction = (LinkedHashMap<String, String>) mySession.getVariableField("ApplicationVariables","transactionHistory").getObjectValue();
						FlatFileWriter ffW = new FlatFileWriter();
						//ffW.createFlatFile("IVR_TRANSACTION_HISTORY", transaction, "TransactionHistory", mySession);
						String jsonString = new Gson().toJson(transaction);
						ffW.createFlatFile(new JsonParser().parse(jsonString).getAsJsonObject(), "TransactionHistory", mySession);
					}
					else
					{
						TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| SP_INSERT_IVR_TRANSACTION_HISTORY : ",  mySession);
						TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| VC_UCID : "          + VC_UCID, mySession);
						TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| VC_CLI_NO : "           + VC_CLI_NO, mySession);
						TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| DT_START_DATE : "    + DT_START_DATE, mySession);
						TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| DT_END_DATE : "      + DT_END_DATE, mySession);
						TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| VC_FUNCTION_NAME : "      + VC_FUNCTION_NAME, mySession);
						TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| VC_HOST_URL : "           + VC_HOST_URL, mySession);
						TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| VC_HOST_REQUEST :"        + VC_HOST_REQUEST, mySession);
						TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| VC_HOST_RESPONSE :"       + VC_HOST_RESPONSE, mySession);
						TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| VC_TRANS_STATUS : "   + VC_TRANS_STATUS, mySession);
						TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| VC_USER_INPUT : "   + VC_USER_INPUT, mySession);

						stmt = con.prepareCall("{call dbo.SP_INSERT_IVR_TRANSACTION_HISTORY( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) }");

						stmt.setString(1, VC_UCID);
						stmt.setString(2, VC_CLI_NO);
						stmt.setString(3, DT_START_DATE);
						stmt.setString(4, DT_END_DATE);
						stmt.setString(5, VC_FUNCTION_NAME);
						stmt.setString(6, VC_HOST_URL);				
						stmt.setString(7, VC_HOST_REQUEST);
						stmt.setString(8, VC_HOST_RESPONSE);
						stmt.setString(9, VC_TRANS_STATUS);
						stmt.setString(10, VC_USER_INPUT);

						stmt.setQueryTimeout(defaultQueryTimeout);
						stmt.execute();
						mySession.getVariableField("ApplicationVariables","DBException").setValue(ApplicationConstants.F);
						mySession.getVariableField("ApplicationVariables","SPException").setValue(ApplicationConstants.F);
						mySession.getVariableField("ApplicationVariables","IsTransactionHistoryInserted").setValue(ApplicationConstants.T);
						TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| TRANSACTION HISTORY INSERTED SUCCESSFULLY  ",mySession);
						returnFlag = true; 
					}
				} else 
				{
					TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| DB EXCEPTION OCCURRED.HENCE CREATING FLAT FILE",mySession);

					LinkedHashMap<String,String> transaction = new LinkedHashMap<String, String>();
					transaction = (LinkedHashMap<String, String>) mySession.getVariableField("ApplicationVariables","transactionHistory").getObjectValue();
					FlatFileWriter ffw = new FlatFileWriter();
					//ffw.createFlatFile("IVR_TRANSACTION_HISTORY", transaction, "TransactionHistory", mySession);
					String jsonString = new Gson().toJson(transaction);
					ffw.createFlatFile(new JsonParser().parse(jsonString).getAsJsonObject(), "TransactionHistory", mySession);
					mySession.getVariableField("ApplicationVariables","IsTransactionHistoryInserted").setValue(ApplicationConstants.T);

					mySession.getVariableField("ApplicationVariables","DBException").setValue(ApplicationConstants.T);
				}
			} else {

				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| DB EXCEPTION OCCURRED.HENCE CREATING FLAT FILE",mySession);
				LinkedHashMap<String,String> transaction = new LinkedHashMap<String, String>();
				transaction = (LinkedHashMap<String, String>) mySession.getVariableField("ApplicationVariables","transactionHistory").getObjectValue();

				FlatFileWriter ffw = new FlatFileWriter();
				//ffw.createFlatFile("IVR_TRANSACTION_HISTORY", transaction, "TransactionHistory", mySession);
				String jsonString = new Gson().toJson(transaction);
				ffw.createFlatFile(new JsonParser().parse(jsonString).getAsJsonObject(), "TransactionHistory", mySession);
				mySession.getVariableField("ApplicationVariables","IsTransactionHistoryInserted").setValue(ApplicationConstants.T);
				mySession.getVariableField("ApplicationVariables","DBException").setValue(ApplicationConstants.T);
			}

		}
		catch(Exception ex)
		{
			LinkedHashMap<String,String> transaction = new LinkedHashMap<String, String>();
			transaction = (LinkedHashMap<String, String>) mySession.getVariableField("ApplicationVariables","transactionHistory").getObjectValue();

			FlatFileWriter ffw = new FlatFileWriter();
			//ffw.createFlatFile("IVR_TRANSACTION_HISTORY", transaction, "TransactionHistory", mySession);
			String jsonString = new Gson().toJson(transaction);
			ffw.createFlatFile(new JsonParser().parse(jsonString).getAsJsonObject(), "TransactionHistory", mySession);
			mySession.getVariableField("ApplicationVariables","IsTransactionHistoryInserted").setValue(ApplicationConstants.T);


			mySession.getVariableField("ApplicationVariables","SPException").setValue(ApplicationConstants.T);
			mySession.getVariableField("ApplicationVariables","DBException").setValue(ApplicationConstants.T);
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| SP_INSERT_IVR_TRANSACTION_HISTORY | DB Error : "+ex.getMessage(),mySession);
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| SP_INSERT_IVR_TRANSACTION_HISTORY | DB Error : "+Arrays.toString(ex.getStackTrace()),mySession);

		}
		finally
		{
			try {

				String exception_1 = mySession.getVariableField("ApplicationVariables","SPException").getStringValue();

				if(exception_1.equalsIgnoreCase(ApplicationConstants.T))
				{
					TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| CONNECTION EXCEPTION WHILE EXECUTE TRANSACTION SP : ",  mySession);
					TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| CONNECTION EXCEPTION WHILE CONNECTING DB: ",  mySession);

					LinkedHashMap<String,String> transaction = new LinkedHashMap<String, String>();
					transaction = (LinkedHashMap<String, String>) mySession.getVariableField("ApplicationVariables","transactionHistory").getObjectValue();

					FlatFileWriter ffw = new FlatFileWriter();
					//ffw.createFlatFile("IVR_TRANSACTION_HISTORY", transaction, "TransactionHistory", mySession);
					String jsonString = new Gson().toJson(transaction);
					ffw.createFlatFile(new JsonParser().parse(jsonString).getAsJsonObject(), "TransactionHistory", mySession);
					mySession.getVariableField("ApplicationVariables","IsTransactionHistoryInserted").setValue(ApplicationConstants.T);
					mySession.getVariableField("ApplicationVariables","SPException").setValue(ApplicationConstants.F);
				}
				try {

					if(stmt!=null) {
						stmt.close();
					}
					if(con!=null) {

						closeConnection(con, mySession);
						TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| SQL CONNECTION CLOSED |",mySession);
					} else {
						TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| SQL CONNECTION IS NULL |",mySession);
					}


				}catch (Exception es) {
					TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| SQL CLOSE CONNECTION EXCEPTION|"+es.getMessage(),mySession);
				}
			} catch (Exception e) {
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| SP_INSERT_TRANSACTION_HISTORY | DB Connection Error : "+e.getMessage(),mySession);
			}
		}
		return returnFlag;
	}

	@SuppressWarnings("unchecked")
	public boolean InsertMenuHistory(SCESession mySession) {

		String methodName = "InsertMenuHistory";
		CallableStatement stmt = null;
		boolean returnFlag = false;
		String exception = mySession.getVariableField("ApplicationVariables","DBException").getStringValue();
		LinkedHashMap<String,String>menumap = new LinkedHashMap<String,String>();

		
		ArrayList<MenuHistoryDT> mhobj = (ArrayList<MenuHistoryDT>) mySession.getVariableField("ApplicationVariables","MenuHistoryObj").getObjectValue();
		HashMap<String,String> property = new HashMap<String, String>();
		property = (HashMap<String, String>) mySession.getVariableField("PropertyFields","PropertyValues").getObjectValue();
		int defaultQueryTimeout = Integer.parseInt(property.get(ApplicationConstants.DB_DefaultQueryTimeout).toString());
		Connection con = openConnection(mySession);
		TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| Menu history object: "+mhobj,  mySession);

		String VC_UCID = "NA";
		String VC_LANGUAGE ="NA";
		String DT_START_DATE ="NA";
		String VC_MENU_TRAVEL = "NA";
		String VC_CALL_END_REASON = "";
		String VC_SEQUENCE ="NA";
		String comma ="";
		String Query="";

		int i=0;


		try
		{

			if(exception.equalsIgnoreCase(ApplicationConstants.F)) {


				if(con!=null) {			

					for (int j=0;j<mhobj.size();j++) {
						
						
						TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| MENU TRAVERSAL :  "+mhobj.get(j).toString(),  mySession);

						VC_UCID = mhobj.get(j).getVC_UCID();
						VC_LANGUAGE =mhobj.get(j).getVC_LANGUAGE();
						DT_START_DATE = mhobj.get(j).getDT_START_DATE();
						VC_MENU_TRAVEL = mhobj.get(j).getVC_MENU_TRAVEL();
					VC_SEQUENCE = String.valueOf(mhobj.get(j).getVC_SEQUENCE());
						


						if(j==mhobj.size()-1) {
							VC_CALL_END_REASON = mySession.getVariableField("Call_History_Fields","VC_CALL_END_REASON").getStringValue();

						}

						Query +=comma+"("+VC_UCID+";"+VC_LANGUAGE+";"+DT_START_DATE+";"+VC_MENU_TRAVEL+";"+VC_CALL_END_REASON+";"+VC_SEQUENCE+")";
						comma =",";

					}

					TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| QUERY : "+Query,  mySession);

					TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| SP_INSERT_MENU_HISTORY : ",  mySession);
					TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| VC_UCID : "          + VC_UCID, mySession);
					TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| VC_LANGUAGE : "           + VC_LANGUAGE, mySession);
					TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| DT_START_DATE : "    + DT_START_DATE, mySession);
					TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| VC_MENU_TRAVEL : "      + VC_MENU_TRAVEL, mySession);
					TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| VC_CALL_END_REASON : "      + VC_CALL_END_REASON, mySession);
					TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| VC_SEQUENCE : "           + VC_SEQUENCE, mySession);

					stmt = con.prepareCall("{call dbo.SP_INSERT_MENU_HISTORY(?) }");

					stmt.setString(1, Query);
					stmt.setQueryTimeout(defaultQueryTimeout);
					stmt.execute();

					mySession.getVariableField("ApplicationVariables","DBException").setValue(ApplicationConstants.F);
					mySession.getVariableField("ApplicationVariables","SPException").setValue(ApplicationConstants.F);
					TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| MENU HISTORY INSERTED SUCCESSFULLY  ",mySession);
					returnFlag = true; 
				}
			} 

		}
		catch(Exception ex)
		{			

			mySession.getVariableField("ApplicationVariables","SPException").setValue(ApplicationConstants.T);
			mySession.getVariableField("ApplicationVariables","DBException").setValue(ApplicationConstants.T);
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| SP_INSERT_MENU_HISTORY | DB Error : "+ex.getMessage(),mySession);

		}
		finally
		{
			try {

				String exception_1 = mySession.getVariableField("ApplicationVariables","SPException").getStringValue();
				String exception_2 = mySession.getVariableField("ApplicationVariables","DBException").getStringValue();

				if(exception_1.equalsIgnoreCase(ApplicationConstants.T ) ||exception_2.equalsIgnoreCase(ApplicationConstants.T ) )
				{
					TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| CONNECTION EXCEPTION WHILE EXECUTE MENU_HISTORY SP : ",  mySession);
					TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| CONNECTION EXCEPTION WHILE CONNECTING DB: ",  mySession);

					for(MenuHistoryDT mdto : mhobj) {

						if(i==mhobj.size()-1) {
							VC_CALL_END_REASON = mySession.getVariableField("Call_History_Fields","VC_CALL_END_REASON").getStringValue();
							mdto.setVC_CALL_END_REASON(VC_CALL_END_REASON);

						}else {
							mdto.setVC_CALL_END_REASON("");					
						}
						menumap.put("VC_UCID", mdto.getVC_UCID());
						menumap.put("VC_LANGUAGE", mdto.getVC_LANGUAGE());
						menumap.put("DT_START_DATE", mdto.getDT_START_DATE());
						menumap.put("VC_MENU_TRAVEL", mdto.getVC_MENU_TRAVEL());
						menumap.put("VC_CALL_END_REASON", mdto.getVC_CALL_END_REASON());
						menumap.put("VC_SEQUENCE", Integer.toString(mdto.getVC_SEQUENCE()));
						FlatFileWriter ffw = new FlatFileWriter();
						//ffw.createFlatFile("IVR_MENU_HISTORY", menumap, "MenuHistory", mySession);
						String jsonString = new Gson().toJson(menumap);
						ffw.createFlatFile(new JsonParser().parse(jsonString).getAsJsonObject(), "MenuHistory", mySession);
						i++;
					}

					mySession.getVariableField("ApplicationVariables","SPException").setValue(ApplicationConstants.F);
				}
				try {

					if(stmt!=null) {
						stmt.close();
					}
					if(con!=null) {

						closeConnection(con, mySession);
						TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| SQL CONNECTION CLOSED |",mySession);
					} else {
						TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| SQL CONNECTION IS NULL |",mySession);
					}


				}catch (Exception es) {
					TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| SQL CLOSE CONNECTION EXCEPTION|"+es.getMessage(),mySession);
				}
			} catch (Exception e) {
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| SP_INSERT_MENU_HISTORY | DB Connection Error : "+e.getMessage(),mySession);
			}
		}
		return returnFlag;
	}

	@SuppressWarnings("unchecked")
	public String getTransferVdn(String DNIS,String VC_LANGUAGE,String VC_EXIT_LOCATION,String Type,String Country,String State,String City,SCESession mySession)
	{
		String methodName = "getTransferVdn";
		CallableStatement stmt = null;
		ResultSet resultSet = null;

		String vdn = "";
		String exception = mySession.getVariableField("ApplicationVariables","DBException").getStringValue();
		HashMap<String,String> property = new HashMap<String, String>();
		property = (HashMap<String, String>) mySession.getVariableField("PropertyFields","PropertyValues").getObjectValue();
		int defaultQueryTimeout = Integer.parseInt(property.get(ApplicationConstants.DB_DefaultQueryTimeout).toString());
		Connection con = openConnection(mySession);
		try
		{
			if(exception.equalsIgnoreCase(ApplicationConstants.F)) {


				if(con!=null) {


					if(exception.equalsIgnoreCase(ApplicationConstants.T))
					{
						TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| CONNECTION EXCEPTION WHILE CONNECTING DB: ",  mySession);
						mySession.getVariableField("ApplicationVariables","DBException").setValue(ApplicationConstants.T);
					}
					else
					{
						stmt = con.prepareCall("{call dbo.SP_SELECT_TRANSFER_MASTER( ?, ?,?,?,?,?,?) }");

						stmt.setString(1, Type);
						stmt.setString(2, DNIS);
						stmt.setString(3, VC_LANGUAGE);
						stmt.setString(4, VC_EXIT_LOCATION);
						stmt.setString(5, Country);
						stmt.setString(6,State);
						stmt.setString(7, City);
						stmt.setQueryTimeout(defaultQueryTimeout);

						resultSet = stmt.executeQuery();

						while (resultSet.next()) {
							vdn = resultSet.getString(1);
							TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| Transfer VDN From DataBase : "+vdn,mySession);
						}

						mySession.getVariableField("ApplicationVariables","DBException").setValue(ApplicationConstants.F);

					}
				} else 
				{
					TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| DB CONNECTION EXCEPTION OCCURRED.HENCE UNABLE TO GET EXIT VDN",mySession);
					mySession.getVariableField("ApplicationVariables","DBException").setValue(ApplicationConstants.T);
				}
			} else {

				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| DB IS UNAVAILABLE DUE TO DB EXCEPTION",mySession);
				mySession.getVariableField("ApplicationVariables","DBException").setValue(ApplicationConstants.T);
			}

		}
		catch(Exception ex)
		{
			mySession.getVariableField("ApplicationVariables","SPException").setValue(ApplicationConstants.T);
			mySession.getVariableField("ApplicationVariables","DBException").setValue(ApplicationConstants.T);
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| SP_SELECT_TRANSFER_VDN | DB Error : "+ex.getMessage(),mySession);
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| SP_SELECT_TRANSFER_VDN | DB Error : "+Arrays.toString(ex.getStackTrace()),mySession);

		}
		finally
		{
			try {

				String exception_1 = mySession.getVariableField("ApplicationVariables","SPException").getStringValue();

				if(exception_1.equalsIgnoreCase(ApplicationConstants.T))
				{
					TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| CONNECTION EXCEPTION WHILE EXECUTE GET VDN SP : ",  mySession);
					TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| CONNECTION EXCEPTION WHILE CONNECTING DB: ",  mySession);
					mySession.getVariableField("ApplicationVariables","SPException").setValue(ApplicationConstants.F);
				}
				try {

					if(stmt!=null) {
						resultSet.close();
						stmt.close();
					}
					if(con!=null) {

						closeConnection(con, mySession);
						TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| SQL CONNECTION CLOSED |",mySession);
					} else {
						TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| SQL CONNECTION IS NULL |",mySession);
					}


				}catch (Exception es) {
					TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| SQL CLOSE CONNECTION EXCEPTION|"+es.getMessage(),mySession);
				}
			} catch (Exception e) {
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| SP_SELECT_TRANSFER_VDN | DB Connection Error : "+e.getMessage(),mySession);
			}
		}
		return vdn;
	}

	@SuppressWarnings("unchecked")
	public String getDnisLanguage(String VC_DNIS,SCESession mySession)
	{
		String methodName = "getDnisLanguage";
		CallableStatement stmt = null;
		ResultSet resultSet = null;

		String Language = "";
		String exception = mySession.getVariableField("ApplicationVariables","DBException").getStringValue();
		HashMap<String,String> property = new HashMap<String, String>();
		property = (HashMap<String, String>) mySession.getVariableField("PropertyFields","PropertyValues").getObjectValue();
		int defaultQueryTimeout = Integer.parseInt(property.get(ApplicationConstants.DB_DefaultQueryTimeout).toString());
		Connection con = openConnection(mySession);
		try
		{
			if(exception.equalsIgnoreCase(ApplicationConstants.F)) {


				if(con!=null) {


					if(exception.equalsIgnoreCase(ApplicationConstants.T))
					{
						TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| CONNECTION EXCEPTION WHILE CONNECTING DB: ",  mySession);
						mySession.getVariableField("ApplicationVariables","DBException").setValue(ApplicationConstants.T);
					}
					else
					{
						stmt = con.prepareCall("{call dbo.SP_SELECT_DNIS_MASTER( ?) }");
						stmt.setQueryTimeout(defaultQueryTimeout);
						stmt.setString(1,VC_DNIS);				


						resultSet = stmt.executeQuery();

						while (resultSet.next()) {
							Language = resultSet.getString(1);
							TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| DNIS Language From DataBase : "+Language,mySession);
						}

						mySession.getVariableField("ApplicationVariables","DBException").setValue(ApplicationConstants.F);

					}
				} else 
				{
					TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| DB CONNECTION EXCEPTION OCCURRED.HENCE UNABLE TO GET LANGUAGE",mySession);
					mySession.getVariableField("ApplicationVariables","DBException").setValue(ApplicationConstants.T);
				}
			} else {

				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| DB IS UNAVAILABLE DUE TO DB EXCEPTION",mySession);
				mySession.getVariableField("ApplicationVariables","DBException").setValue(ApplicationConstants.T);
			}

		}
		catch(Exception ex)
		{
			mySession.getVariableField("ApplicationVariables","SPException").setValue(ApplicationConstants.T);
			mySession.getVariableField("ApplicationVariables","DBException").setValue(ApplicationConstants.T);
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| SP_SELECT_DNIS_MASTER | DB Error : "+ex.getMessage(),mySession);
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| SP_SELECT_DNIS_MASTER | DB Error : "+Arrays.toString(ex.getStackTrace()),mySession);

		}
		finally
		{
			try {

				String exception_1 = mySession.getVariableField("ApplicationVariables","SPException").getStringValue();

				if(exception_1.equalsIgnoreCase(ApplicationConstants.T))
				{
					TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| CONNECTION EXCEPTION WHILE EXECUTE GET DNIS MASTER SP : ",  mySession);
					TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| CONNECTION EXCEPTION WHILE CONNECTING DB: ",  mySession);
					mySession.getVariableField("ApplicationVariables","SPException").setValue(ApplicationConstants.F);
				}
				try {

					if(stmt!=null) {
						resultSet.close();
						stmt.close();
					}
					if(con!=null) {

						closeConnection(con, mySession);
						TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| SQL CONNECTION CLOSED |",mySession);
					} else {
						TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| SQL CONNECTION IS NULL |",mySession);
					}


				}catch (Exception es) {
					TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| SQL CLOSE CONNECTION EXCEPTION|"+es.getMessage(),mySession);
				}
			} catch (Exception e) {
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| SP_SELECT_TRANSFER_VDN | DB Connection Error : "+e.getMessage(),mySession);
			}
		}
		return Language;
	}

	@SuppressWarnings("unchecked")
	public HashMap<String,String> validateUser(String userID,SCESession mySession) {


		String methodName = "validateUser";
		CallableStatement stmt = null;
		ResultSet resultSet = null;

		String type = "";
		String vdn = "";


		String exception = mySession.getVariableField("ApplicationVariables","DBException").getStringValue();
		HashMap<String,String> values = null;
		HashMap<String,String> property = new HashMap<String, String>();
		property = (HashMap<String, String>) mySession.getVariableField("PropertyFields","PropertyValues").getObjectValue();
		int defaultQueryTimeout = Integer.parseInt(property.get(ApplicationConstants.DB_DefaultQueryTimeout).toString());
		Connection con = openConnection(mySession);
		try
		{
			if(exception.equalsIgnoreCase(ApplicationConstants.F)) {


				if(con!=null) {


					if(exception.equalsIgnoreCase(ApplicationConstants.T)){
						
						TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| CONNECTION EXCEPTION WHILE CONNECTING DB: ",  mySession);
						mySession.getVariableField("ApplicationVariables","DBException").setValue(ApplicationConstants.T);
					}
					else{
						stmt = con.prepareCall("{call dbo.SP_SELECT_USER_MASTER( ?) }");
						stmt.setQueryTimeout(defaultQueryTimeout);
						stmt.setString(1,userID);				


						resultSet = stmt.executeQuery();

						values = new HashMap<String,String>();

						while (resultSet.next()) {
							type = resultSet.getString(1);
							vdn = resultSet.getString(2);


						}

						values.put("VC_TYPE", type);
						values.put("VC_TRANSFER_VDN", vdn);

						TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| USER TYPE : "+type,mySession);
						TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| TRANSFER VDN : "+vdn,mySession);

						mySession.getVariableField("ApplicationVariables","DBException").setValue(ApplicationConstants.F);

					}
				} else 
				{
					TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| DB CONNECTION EXCEPTION OCCURRED.HENCE UNABLE TO VALIDATE USER",mySession);
					mySession.getVariableField("ApplicationVariables","DBException").setValue(ApplicationConstants.T);
				}
			} else {

				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| DB IS UNAVAILABLE DUE TO DB EXCEPTION",mySession);
				mySession.getVariableField("ApplicationVariables","DBException").setValue(ApplicationConstants.T);
			}

		}
		catch(Exception ex)
		{
			mySession.getVariableField("ApplicationVariables","SPException").setValue(ApplicationConstants.T);
			mySession.getVariableField("ApplicationVariables","DBException").setValue(ApplicationConstants.T);
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| SP_SELECT_USER_MASTER | DB Error : "+ex.getMessage(),mySession);
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| SP_SELECT_USER_MASTER | DB Error : "+Arrays.toString(ex.getStackTrace()),mySession);

		}
		finally
		{
			try {

				String exception_1 = mySession.getVariableField("ApplicationVariables","SPException").getStringValue();

				if(exception_1.equalsIgnoreCase(ApplicationConstants.T))
				{
					TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| CONNECTION EXCEPTION WHILE EXECUTE VALIDATE USER SP : ",  mySession);
					TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| CONNECTION EXCEPTION WHILE CONNECTING DB: ",  mySession);
					mySession.getVariableField("ApplicationVariables","SPException").setValue(ApplicationConstants.F);
				}
				try {

					if(stmt!=null) {
						resultSet.close();
						stmt.close();
					}
					if(con!=null) {

						closeConnection(con, mySession);
						TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| SQL CONNECTION CLOSED |",mySession);
					} else {
						TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| SQL CONNECTION IS NULL |",mySession);
					}


				}catch (Exception es) {
					TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| SQL CLOSE CONNECTION EXCEPTION|"+es.getMessage(),mySession);
				}
			} catch (Exception e) {
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| SP_SELECT_TRANSFER_VDN | DB Connection Error : "+e.getMessage(),mySession);
			}
		}

		return values;

	}

}
