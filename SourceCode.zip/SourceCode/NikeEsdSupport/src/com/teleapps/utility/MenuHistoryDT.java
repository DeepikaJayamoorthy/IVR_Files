package com.teleapps.utility;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;

import com.avaya.sce.runtime.tracking.TraceInfo;
import com.avaya.sce.runtimecommon.ITraceInfo;
import com.avaya.sce.runtimecommon.SCESession;



public class MenuHistoryDT {
	
	private String VC_UCID;
	private String VC_LANGUAGE;
	private String DT_START_DATE;
	private String VC_MENU_TRAVEL;
	private String VC_CALL_END_REASON;
	private int VC_SEQUENCE;
	private SCESession mySession;
	
	
	
	
	
	public MenuHistoryDT() {
		super();
	}

	@SuppressWarnings("unchecked")
	public MenuHistoryDT(String vC_MENU_TRAVEL,SCESession mySession) {
		super();
		
		TimeZoneConversion zone = new TimeZoneConversion();
		HashMap<String,String> property = new HashMap<String, String>();
		property = (HashMap<String, String>) mySession.getVariableField("PropertyFields","PropertyValues").getObjectValue();
		
		DT_START_DATE = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(new Date());;
		
		String TimeZoneFlag = property.get("TIME_ZONE_FLAG");
		
		if(TimeZoneFlag.equalsIgnoreCase("true")) {
			DT_START_DATE = zone.calculateTimeZone(DT_START_DATE, mySession);
		}
		
		LinkedHashMap<String,String> callHistory = new LinkedHashMap<String, String>();
		callHistory = (LinkedHashMap<String, String>) mySession.getVariableField("ApplicationVariables","callHistory").getObjectValue();	
		
		
		VC_UCID = callHistory.get("VC_UCID");
		VC_LANGUAGE = mySession.getVariableField("ApplicationVariables","Language").getStringValue();
		
		
		
		
		VC_MENU_TRAVEL = vC_MENU_TRAVEL;
		VC_SEQUENCE = mySession.getVariableField("ApplicationVariables","MenuSequence").getIntValue();
		mySession.getVariableField("ApplicationVariables","MenuSequence").setValue(VC_SEQUENCE+1);
		this.mySession = mySession;
	}
	
	public void set( MenuHistoryDT mhdt ,SCESession mySession) {
		@SuppressWarnings("unchecked")
		ArrayList<MenuHistoryDT> mhobj = (ArrayList<MenuHistoryDT>) mySession.getVariableField("ApplicationVariables","MenuHistoryObj").getObjectValue();
		TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO,"MenuReportDto "+" <-> MenuReportDTO Object Added : "+mhdt.toString(),  mySession);
		mhobj.add(mhdt);
		mySession.getVariableField("ApplicationVariables","MenuHistoryObj").setValue(mhobj);
	}
	
	

	public String getVC_UCID() {
		return VC_UCID;
	}

	public void setVC_UCID(String vC_UCID) {
		VC_UCID = vC_UCID;
	}

	public String getVC_LANGUAGE() {
		return VC_LANGUAGE;
	}

	public void setVC_LANGUAGE(String vC_LANGUAGE) {
		VC_LANGUAGE = vC_LANGUAGE;
	}

	public String getDT_START_DATE() {
		return DT_START_DATE;
	}

	public void setDT_START_DATE(String dT_START_DATE) {
		DT_START_DATE = dT_START_DATE;
	}

	public String getVC_MENU_TRAVEL() {
		return VC_MENU_TRAVEL;
	}

	public void setVC_MENU_TRAVEL(String vC_MENU_TRAVEL) {
		VC_MENU_TRAVEL = vC_MENU_TRAVEL;
	}

	public String getVC_CALL_END_REASON() {
		return VC_CALL_END_REASON;
	}

	public void setVC_CALL_END_REASON(String vC_CALL_END_REASON) {
		VC_CALL_END_REASON = vC_CALL_END_REASON;
	}

	public int getVC_SEQUENCE() {
		return VC_SEQUENCE;
	}

	public void setVC_SEQUENCE(int vC_SEQUENCE) {
		VC_SEQUENCE = vC_SEQUENCE;
	}

	public SCESession getMySession() {
		return mySession;
	}

	public void setMySession(SCESession mySession) {
		this.mySession = mySession;
	}

	@Override
	public String toString() {
		return "MenuHistoryDT [VC_UCID=" + VC_UCID + ", VC_LANGUAGE=" + VC_LANGUAGE + ", DT_START_DATE=" + DT_START_DATE
				+ ", VC_MENU_TRAVEL=" + VC_MENU_TRAVEL + ", VC_CALL_END_REASON=" + VC_CALL_END_REASON + ", VC_SEQUENCE="
				+ VC_SEQUENCE + ", mySession=" + mySession + "]";
	}
	
	
	
	

}
