package com.teleapps.utility;

public class ApplicationConstants {
	
	//flag values
		public static String T = "true";
		public static String F = "false";
		
		//Transfer VDN
		public static String TransferVdn = "TRANSFER_VDN";
		
		//Default keys
		public static String PropertyFile = "PropertyFile";
		public static String flatFilePath = "FLAT_FILE_PATH";
		public static String PromptLocation = "PROMPT_LOCATION";
		public static String DefaultLanguage = "DEFAULT_LANGUAGE";
		public static String RetryCount = "RETRY_COUNT";
		public static String CumulativeRetry = "CUMULATIVE_RETRY";
		
		//DB_Config property keys
		public static String DB_Primary_IP = "DATABASE_IP";
		public static String DB_Schema = "SCHEMA_NAME";
		public static String DB_Username = "DB_USER_NAME";
		public static String DB_Password = "DB_PASSWORD";
		public static String DB_Timeout = "DB_TIMEOUT";
		public static String DB_DefaultQueryTimeout = "DB_QUERY_DEFAULT_TIMEOUT";
		public static String DB_MinIdle = "DB_MIN_IDLE";
		public static String DB_MaxIdle = "DB_MAX_IDLE";
		public static String DB_Open_Prepared_Statement = "DB_MAX_OPEN_PREPARED_STATEMENT";
		
		//Property API keys
		public static String Snowusername = "SNOW_USER_NAME";
		public static String Snowpassword = "SNOW_PASSWORD";
		public static String jksFilePath = "JKS_FILE_PATH";
		public static String jksPassword = "JKS_PASSWORD";
		public static String proxyStatus = "PROXY_ENABLE_STATUS";
		public static String proxydomain = "PROXY_DOMAIN";
		public static String proxyPort = "PROXY_PORT";
		public static String ConnectTimeout = "CONNECT_TIMEOUT";
		public static String ReadTimeout = "READ_TIMEOUT";
		
		//Call End Reason
		public static String Hangup = "HANGUP";
		public static String Transfer = "TRANSFER";
		public static String Disconnect = "DISCONNECT";
		public static String AppError = "APP_ERROR";
		public static String BadFetch = "BAD_FETCH";
		
		//Transitional Audio
		public static String TransitionFolder = "GENERAL";
		public static String TransitionAudio = "TRANSITION_AUDIO.wav";
				

}
