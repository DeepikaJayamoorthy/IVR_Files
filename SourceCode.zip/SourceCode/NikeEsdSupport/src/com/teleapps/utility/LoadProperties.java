package com.teleapps.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Properties;

import com.avaya.sce.runtime.tracking.TraceInfo;
import com.avaya.sce.runtimecommon.ITraceInfo;
import com.avaya.sce.runtimecommon.SCESession;

public class LoadProperties {
	

	
	String CLASSNAME = "LoadProperties";
	
	
	static String file_old_time;
	public static HashMap<String,String> property = null;
	
	
	
	public  String getFileTime(String filePath,SCESession mySession) {
	    File file = null;
		String methodName = "getFileTime";
		String file_last_modified_time;
		file = new File(filePath);
		long modified = file.lastModified();
		SimpleDateFormat formater = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
		Date date = new Date(modified); 
		file_last_modified_time = formater.format(date);
		TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| ***FILE : "+filePath,mySession);
		TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| ***FILE MODIFIED TIME: "+file_last_modified_time, mySession);
		
		return file_last_modified_time;
	}
	
	public void readProperties(String filePath,SCESession mySession) {
		
			String methodName = "readProperties";
			
		try {
			String file_last_modified_time = getFileTime(filePath, mySession);
			
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| ***PROPERTY FETCH***", mySession);
			if(file_last_modified_time.equals(file_old_time)) {
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| ***PROPERTY FILE NOT MODIFIED***", mySession);
				setProperty(filePath,mySession);				
				
								
			} else {
				file_old_time = file_last_modified_time;
				mySession.getVariableField("PropertyFields","IsPropModified").setValue(true);
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| ***FILE MODIFIED***", mySession);
				
				loadProperty(filePath,mySession);
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| ***PROPERTY FILE LOADED***", mySession);
				
				
				
			}
			
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| ***PROPERTY FETCH COMPLETED***", mySession);
			
		} catch(Exception e) {
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| ***ERROR IN FETCHING PROPERTIES***"+e.getMessage(), mySession);
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| ***ERROR IN FETCHING PROPERTIES***"+Arrays.toString(e.getStackTrace()), mySession);
			
		}
		
		
	}
	
	@SuppressWarnings("rawtypes")
	public void loadProperty(String filePath,SCESession mySession) {
		String methodName = "loadProperty";
		FileInputStream fileInput = null;
		try {
			Properties properties = new Properties();
			property = new HashMap<String,String>();
			
			fileInput = new FileInputStream(filePath);
			properties.load(fileInput);
			
			Enumeration enukeys = properties.keys();
			while(enukeys.hasMoreElements()) {
				String key = (String) enukeys.nextElement();
				String value = properties.getProperty(key);
				property.put(key, value);	
			}
			mySession.getVariableField("PropertyFields","PropertyValues").setValue(property);
		
		} catch(Exception e) {
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| ***ERROR IN LOADING AND READING PROPERTIES***"+e.getMessage(), mySession);
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| ***ERROR IN LOADING AND READING PROPERTIES***"+Arrays.toString(e.getStackTrace()), mySession);
		}
		finally {
			try {
				fileInput.close();
			} catch (IOException e) {
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| ***ERROR IN CLOSING FILE READER***"+e.getMessage(), mySession);
				TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| ***ERROR IN CLOSING FILE READER***"+Arrays.toString(e.getStackTrace()), mySession);
			}
		}
	}
	
	public void setProperty(String filePath,SCESession mySession) {
		String methodName = "setProperty";
		mySession.getVariableField("PropertyFields","PropertyValues").setValue(property);
		TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO, CLASSNAME+"|"+methodName+"| ***LOADING RETAINED VALUES***", mySession);
		
	}
	
	
	





}
