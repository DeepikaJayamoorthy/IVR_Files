package com.teleapps.utility;

import com.avaya.sce.runtime.tracking.TraceInfo;
import com.avaya.sce.runtimecommon.ITraceInfo;
import com.avaya.sce.runtimecommon.SCESession;

public class DynamicVariable {
	public void initialize(int size,SCESession mySession) {

		com.avaya.sce.runtimecommon.IVariable variable = null;		
		try{
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO,"creating dynamic variables :", mySession);
			for(int promptName=0;promptName<size;promptName++){
				variable = com.avaya.sce.runtime.SimpleVariable.createSimpleVariable("audio"+promptName, "NA", null, mySession, false, false );
				mySession.putVariable(variable);
			}
		} catch (Exception ex){
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR,"error while creating dynamic variables :"+ex.getMessage(), mySession);
		}
	}
	public void createVariable(String variableName,SCESession mySession) {
		com.avaya.sce.runtimecommon.IVariable variable = null;		
		try{
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_INFO,"creating dynamic variables :", mySession);
				variable = com.avaya.sce.runtime.SimpleVariable.createSimpleVariable(variableName, "NA", null, mySession, false, false );
				mySession.putVariable(variable);
		} catch (Exception ex){
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR,"error while creating dynamic variables :"+ex.getMessage(), mySession);
		}
	}

}
