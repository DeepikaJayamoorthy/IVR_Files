package com.teleapps.utility;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.TimeZone;

import com.avaya.sce.runtime.tracking.TraceInfo;
import com.avaya.sce.runtimecommon.ITraceInfo;
import com.avaya.sce.runtimecommon.SCESession;

public class TimeZoneConversion {
	
	String CLASSNAME = "TimeZoneConversion";

	@SuppressWarnings({ "unchecked"})
	public String calculateTimeZone(String date,SCESession mySession) {
		String methodName = "calculateTimeZone";
		String response = "";
		try {

			HashMap<String,String> property = new HashMap<String, String>();
			property = (HashMap<String, String>) mySession.getVariableField("PropertyFields","PropertyValues").getObjectValue();
			String GMT = "";

			GMT = property.get("RECORDS_TIMEZONE");

			Date dateInput = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").parse(date);
			
			//GMT Format
			DateFormat gmtFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
			TimeZone gmtTime = TimeZone.getTimeZone(GMT);
			gmtFormat.setTimeZone(gmtTime);
			
			response = gmtFormat.format(dateInput);
			
		} catch(Exception e) {
			TraceInfo.trace(ITraceInfo.TRACE_LEVEL_ERROR, CLASSNAME+"|"+methodName+"| EXCEPTION IN CONVERTING TIME ZONE : "+e.getMessage(), mySession);
		}
		return response;
	}

}
